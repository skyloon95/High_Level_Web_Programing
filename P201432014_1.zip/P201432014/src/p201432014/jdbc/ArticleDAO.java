package p201432014.jdbc;

public class ArticleDAO {

}
